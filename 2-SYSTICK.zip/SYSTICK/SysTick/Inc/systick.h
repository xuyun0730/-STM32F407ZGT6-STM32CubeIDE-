/*
 * systick.h
 *
 *  Created on: Feb 17, 2025
 *      Author: ����
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

#include "main.h"

void SysTick_Init(uint8_t SYSCLK);
void delay_ms(uint16_t nms);
void delay_us(uint32_t nus);
void delay_s(uint16_t n);

#endif /* SYSTICK_H_ */
